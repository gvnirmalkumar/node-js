import React from "react";
import { Row,Col } from 'react-bootstrap';
import './new.css';
import Carousel from 'react-bootstrap/Carousel';


export default function home() {
  return ( 
      <div>
        <div className="aboutpadding">
   <Row>
       <Col lg={6} className="aboutpadding">
           <div className="abouttitle">
             <span className="abouttitlecolor">About</span>  
             <span className="knowlogytitlecolor"> Knowlogy</span>             
           </div>
           <p className="aboutcontent">
           Knowlogy is a privately held Women-Owned company with over 28 years of experience in the delivery of Technical Training Solutions. Our organization is dedicated to providing quality education to meet the needs of each individual client. Knowlogy’s commitment to innovation has placed us on the leading edge of the computer technology industry locally, nationally, and globally.
          <br/><br/> <button className="learnbutton">Learn More</button>
           </p>
          
       </Col>
       
       <Col lg={6}>
           <Row>
<Col lg={6}>
    
    <div className="year animated bounce">
        <div className="year-opacity">
    <span className="count">28</span><br/>
    <span className="clients">Years</span>
    </div>
    </div>
</Col>
<Col lg={6}>
<div className="client">
    <span className="count">300+</span><br/>
    <span className="clients">Clients</span>
    </div>
</Col>
           </Row>
           <Row>
<Col lg={6}>
<div className="client">
    <span className="count">700+</span><br/>
    <span className="clients">Courses</span>
    </div>
</Col>
<Col lg={6}>
<div className="partners animated bounce-2">
<div className="year-opacity">
    <span className="count">120</span><br/>
    <span className="clients">Partners</span>
    </div>
    </div>
    </Col>               
           </Row>
       </Col>
   </Row>
   </div>
   <div className="focuspadding">
       <div className="focusbk">      
       <Row>
       <div className="abouttitle">
             <span className="focustitlecolor">Our</span>  
             <span className="knowlogytitlecolor"> Focus</span>             
           </div>
       <Col lg={4} className="training">
           <div className="training-padding solutions">
           <img src="https://knowlogy.com/wp-content/uploads/2020/11/Picture6.png" className="training-icon"/>
           <h3 className="training-head">Training Solutions</h3>
           <p className="training-paragraph">For IT training courses, look no further. Knowlogy has long been recognized as a leader in technology training – for good reason!</p>
           <a href="#" className="training-read">Read More <i class="fa fa-arrow-right"></i></a>
           </div>
       </Col>
       <Col lg={4} className="training">
       <div className="training-padding government">
           <img src="https://knowlogy.com/wp-content/uploads/2020/11/Picture5.png" className="training-icon"/>
           <h3 className="training-head">Government Training</h3>
           <p className="training-paragraph">Federal, state, and local government agencies use Knowlogy to design, manage, implement, and maintain effective IT and business training</p>
           <a href="#" className="training-read">Read More <i class="fa fa-arrow-right"></i></a>
           </div>
       </Col>
       <Col lg={4} className="training">
       <div className="training-padding services">
           <img src="https://knowlogy.com/wp-content/uploads/2020/12/coding-white.png" className="training-icon"/>
           <h3 className="training-head">Consulting Services</h3>
           <p className="training-paragraph">Knowlogy is a Microsoft Silver level partner and has a proven track record of providing clients with state-of-the-art solutions</p>
           <a href="#" className="training-read">Read More <i class="fa fa-arrow-right"></i></a>
           </div>
       </Col>
       </Row>    
       </div>
   </div>
   <div>
   <div className="aboutpadding">
   <Row>
       <Col lg={12} className="aboutpadding">
           <div className="abouttitle">
           <span className="knowlogytitlecolor">Trusted</span> 
             <span className="abouttitlecolor"> Training Partners</span>                          
           </div>

           </Col></Row>
           <Carousel >
                <Carousel.Item style={{'height':"300px"}}>
                <img style={{'height':"300px"}}
                    className="d-block w-100"
                    src="https://www.nicesnippets.com/upload/thumbnail/month.png"
                    alt="First slide"
                />
                <Carousel.Caption>
                    <h3>NiceSnippets.com slide label</h3>
                    <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item style={{'height':"300px"}}>
                <img style={{'height':"300px"}}
                    className="d-block w-100"
                    src="https://www.nicesnippets.com/upload/thumbnail/year.png"
                    alt="Third slide"
                />
            
                <Carousel.Caption>
                    <h3>NiceSnippets.com slide label</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item style={{'height':"300px"}}>
                <img style={{'height':"300px"}}
                    className="d-block w-100"
                    src="https://www.nicesnippets.com/upload/thumbnail/footer-social-icon-design-example-using-bootstrap-4.png"
                    alt="Third slide"
                />
            
                <Carousel.Caption>
                    <h3>NiceSnippets.com slide label</h3>
                    <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                </Carousel.Caption>
                </Carousel.Item>
            </Carousel>     
   </div> </div>
   </div>
  );
}

