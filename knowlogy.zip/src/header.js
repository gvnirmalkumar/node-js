import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import { Navbar,Nav,Col } from 'react-bootstrap';
import logo from './Knowlogy Logo-2.svg';
import cart from './shopping-cart-green.svg';
import usergreen from './user-green.svg';
import './new.css';
import About from './about';
import Home from './home';

export default function header() {
  return (   
    
    <Router>
      <div>              
        <Navbar className="bg-color navbar-dark" expand="xl" >            
     <Col lg="2"></Col>    
       <Col lg="8">
       <Navbar.Brand as={Link} to="/" className="text-center"><img src={logo} className="Applogo" alt="logo" /></Navbar.Brand> 
       </Col>
       <Col lg="2"><span className="iconspan">
       <Nav.Link as={Link} to="/" className="cart"><img src={usergreen} className="carticon" alt="logo" /> Login</Nav.Link>
       <Nav.Link as={Link} to="/" className="cart"><img src={cart} className="carticon" alt="logo" /> Cart</Nav.Link> </span>
       </Col>      
      
         </Navbar>
         <Navbar className="bg-color navbar-dark" expand="xl" >                     
          
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav" className="ml-auto justify-content-center">        
        <Col xl="2">
        <Nav.Link as={Link} to="/" activeStyle>Training Solutions</Nav.Link>
          </Col>
           <Col xl="3">
           <Nav.Link as={Link} to="/about">Government Training</Nav.Link>
           </Col>
         <Col xl="2">
         <Nav.Link as={Link} to="/users">Consulting Services</Nav.Link>
          </Col> 
          <Col xl="3">
         <Nav.Link as={Link} to="/users">Events & Meeting Space</Nav.Link>
          </Col> 
          <Col xl="2">
         <Nav.Link as={Link} to="/users">Company</Nav.Link>
          </Col> 
         
        </Navbar.Collapse>  
       
                  
        </Navbar>

        {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
         
        <Switch>
          <Route path="/about">
            <About />
          </Route>
          <Route path="/users">
            <Users />
          </Route>
          <Route path="/">
            <Home />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}


function Users() {
  return <h2>Users</h2>;
}