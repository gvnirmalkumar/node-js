import React from "react";
import './new.css';

export default function about() {
  return (   
    <h2>About</h2>
  );
}

