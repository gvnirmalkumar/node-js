import './App.css';
import New from './header';

function App() {
  return (
    <div className="App">
      <New />
    </div>
  );
}

export default App;
